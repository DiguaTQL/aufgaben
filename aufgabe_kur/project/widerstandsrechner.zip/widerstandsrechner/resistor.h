#ifndef _resistor_h_
#define _resistor_h_

struct resistor{
    int Ring_1_nr, Ring_2_nr, Ring_3_nr, Tempko;
    double  Multifakt;
    char Toleranz[10];
};
#endif